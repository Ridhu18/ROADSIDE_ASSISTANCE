import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { ArrowLeft, Car, Star, MapPin, Filter, Search, Clock, MessageSquare } from "lucide-react"

export default function MechanicPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">Find a Mechanic</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Search and Filter */}
          <div className="flex items-center gap-2 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search mechanics..." className="pl-9" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="w-4 h-4" />
            </Button>
          </div>

          {/* Map Preview */}
          <Card className="overflow-hidden mb-6">
            <div className="relative aspect-[16/9] bg-gray-100">
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-muted-foreground">Map view loading...</p>
              </div>
              <div className="absolute bottom-4 right-4">
                <Button size="sm" className="shadow-md">
                  <MapPin className="w-4 h-4 mr-2" />
                  View Full Map
                </Button>
              </div>
            </div>
          </Card>

          {/* Mechanics List */}
          <Tabs defaultValue="nearby" className="mb-6">
            <TabsList className="w-full">
              <TabsTrigger value="nearby" className="flex-1">
                Nearby
              </TabsTrigger>
              <TabsTrigger value="rated" className="flex-1">
                Top Rated
              </TabsTrigger>
              <TabsTrigger value="quick" className="flex-1">
                Quickest
              </TabsTrigger>
            </TabsList>

            <TabsContent value="nearby" className="mt-4">
              <div className="space-y-4">
                <MechanicCard
                  id="1"
                  name="John's Auto Repair"
                  specialty="General Mechanic"
                  distance="0.8 miles"
                  rating={4.8}
                  reviews={124}
                  eta="10 min"
                  price="$$$"
                  available={true}
                />

                <MechanicCard
                  id="2"
                  name="Quick Fix Mechanics"
                  specialty="Engine Specialist"
                  distance="1.2 miles"
                  rating={4.6}
                  reviews={86}
                  eta="15 min"
                  price="$$"
                  available={true}
                />

                <MechanicCard
                  id="3"
                  name="Elite Auto Service"
                  specialty="Electrical Systems"
                  distance="2.5 miles"
                  rating={4.9}
                  reviews={210}
                  eta="25 min"
                  price="$$$$"
                  available={true}
                />

                <MechanicCard
                  id="4"
                  name="City Mechanics"
                  specialty="Transmission Specialist"
                  distance="3.1 miles"
                  rating={4.5}
                  reviews={78}
                  eta="30 min"
                  price="$$$"
                  available={false}
                />
              </div>
            </TabsContent>

            <TabsContent value="rated">
              <div className="p-8 text-center">
                <p className="text-muted-foreground">Top rated mechanics will appear here</p>
              </div>
            </TabsContent>

            <TabsContent value="quick">
              <div className="p-8 text-center">
                <p className="text-muted-foreground">Quickest response mechanics will appear here</p>
              </div>
            </TabsContent>
          </Tabs>

          {/* Recently Viewed */}
          <h3 className="font-medium mb-3">Recently Viewed</h3>
          <div className="grid grid-cols-2 gap-3 mb-6">
            <RecentCard name="Mike's Auto Shop" type="Mechanic" rating={4.7} />
            <RecentCard name="Pro Mechanics" type="Mechanic" rating={4.5} />
          </div>
        </div>
      </main>

      {/* AI Assistant */}
      <div className="fixed bottom-4 right-4">
        <Button className="w-12 h-12 rounded-full shadow-lg" size="icon">
          <MessageSquare className="w-6 h-6" />
        </Button>
      </div>
    </div>
  )
}

function MechanicCard({
  id,
  name,
  specialty,
  distance,
  rating,
  reviews,
  eta,
  price,
  available,
}: {
  id: string
  name: string
  specialty: string
  distance: string
  rating: number
  reviews: number
  eta: string
  price: string
  available: boolean
}) {
  return (
    <Card className="overflow-hidden">
      <div className="p-4">
        <div className="flex items-start">
          <div className="w-16 h-16 mr-3 overflow-hidden rounded-lg bg-gray-100 flex items-center justify-center">
            <Car className="w-8 h-8 text-primary" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{name}</h3>
              <span className="text-xs font-medium">{price}</span>
            </div>
            <p className="text-sm text-muted-foreground">{specialty}</p>
            <div className="flex items-center mt-1 mb-2">
              <div className="flex items-center mr-3">
                <Star className="w-4 h-4 mr-1 text-yellow-500 fill-yellow-500" />
                <span className="text-sm font-medium">{rating}</span>
                <span className="ml-1 text-xs text-muted-foreground">({reviews})</span>
              </div>
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{distance}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">ETA: {eta}</span>
              </div>
              <div className="flex gap-2">
                <Link href={`/services/mechanic/${id}`}>
                  <Button size="sm" variant="outline">
                    Details
                  </Button>
                </Link>
                <Button size="sm" disabled={!available}>
                  {available ? "Request" : "Unavailable"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}

function RecentCard({
  name,
  type,
  rating,
}: {
  name: string
  type: string
  rating: number
}) {
  return (
    <Card className="overflow-hidden">
      <div className="p-3">
        <div className="flex items-center mb-2">
          <div className="w-8 h-8 mr-2 overflow-hidden rounded-full bg-gray-100 flex items-center justify-center">
            <Car className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h4 className="font-medium text-sm">{name}</h4>
            <p className="text-xs text-muted-foreground">{type}</p>
          </div>
        </div>
        <div className="flex items-center">
          <Star className="w-3 h-3 mr-1 text-yellow-500 fill-yellow-500" />
          <span className="text-xs font-medium">{rating}</span>
        </div>
      </div>
    </Card>
  )
}

