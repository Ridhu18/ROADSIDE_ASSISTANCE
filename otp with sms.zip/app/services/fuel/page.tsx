import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import Link from "next/link"
import { ArrowLeft, MapPin, CreditCard, Info, Clock } from "lucide-react"

export default function FuelDeliveryPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">Fuel Delivery</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Location */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="font-medium mb-3">Delivery Location</h3>
              <div className="flex items-start mb-4">
                <MapPin className="w-5 h-5 mt-1 mr-3 text-primary" />
                <div>
                  <h4 className="font-medium">Current Location</h4>
                  <p className="text-sm text-muted-foreground">123 Main Street, Anytown</p>
                  <Button variant="link" className="p-0 h-auto text-primary text-sm">
                    Change Location
                  </Button>
                </div>
              </div>

              <div className="relative w-full h-40 bg-gray-100 rounded-lg">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-muted-foreground">Map loading...</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Fuel Type */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="font-medium mb-3">Fuel Type</h3>
              <RadioGroup defaultValue="regular">
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center space-x-2 border rounded-lg p-3">
                    <RadioGroupItem value="regular" id="regular" />
                    <Label htmlFor="regular" className="flex-1">
                      <div className="font-medium">Regular</div>
                      <div className="text-sm text-muted-foreground">87 Octane</div>
                    </Label>
                    <div className="font-medium">$3.49/gal</div>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-lg p-3">
                    <RadioGroupItem value="midgrade" id="midgrade" />
                    <Label htmlFor="midgrade" className="flex-1">
                      <div className="font-medium">Midgrade</div>
                      <div className="text-sm text-muted-foreground">89 Octane</div>
                    </Label>
                    <div className="font-medium">$3.79/gal</div>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-lg p-3">
                    <RadioGroupItem value="premium" id="premium" />
                    <Label htmlFor="premium" className="flex-1">
                      <div className="font-medium">Premium</div>
                      <div className="text-sm text-muted-foreground">91 Octane</div>
                    </Label>
                    <div className="font-medium">$4.09/gal</div>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-lg p-3">
                    <RadioGroupItem value="diesel" id="diesel" />
                    <Label htmlFor="diesel" className="flex-1">
                      <div className="font-medium">Diesel</div>
                      <div className="text-sm text-muted-foreground">Ultra Low Sulfur</div>
                    </Label>
                    <div className="font-medium">$3.89/gal</div>
                  </div>
                </div>
              </RadioGroup>
            </div>
          </Card>

          {/* Quantity */}
          <Card className="mb-6">
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium">Quantity</h3>
                <div className="text-sm font-medium">3 Gallons</div>
              </div>

              <Slider defaultValue={[3]} max={10} step={1} className="mb-4" />

              <div className="flex justify-between text-sm text-muted-foreground">
                <span>1 gal</span>
                <span>5 gal</span>
                <span>10 gal</span>
              </div>

              <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex items-start">
                  <Info className="w-4 h-4 mt-0.5 mr-2 text-amber-600" />
                  <p className="text-sm text-amber-800">
                    Most vehicles need 2-3 gallons to reach the nearest gas station. We recommend ordering enough fuel
                    to reach a station safely.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Vehicle Info */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="font-medium mb-3">Vehicle Information</h3>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="vehicle-make">Make</Label>
                  <Select defaultValue="toyota">
                    <SelectTrigger id="vehicle-make">
                      <SelectValue placeholder="Select make" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="toyota">Toyota</SelectItem>
                      <SelectItem value="honda">Honda</SelectItem>
                      <SelectItem value="ford">Ford</SelectItem>
                      <SelectItem value="chevrolet">Chevrolet</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="vehicle-model">Model</Label>
                  <Select defaultValue="camry">
                    <SelectTrigger id="vehicle-model">
                      <SelectValue placeholder="Select model" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="camry">Camry</SelectItem>
                      <SelectItem value="corolla">Corolla</SelectItem>
                      <SelectItem value="rav4">RAV4</SelectItem>
                      <SelectItem value="highlander">Highlander</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="vehicle-color">Color</Label>
                  <Select defaultValue="silver">
                    <SelectTrigger id="vehicle-color">
                      <SelectValue placeholder="Select color" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="black">Black</SelectItem>
                      <SelectItem value="white">White</SelectItem>
                      <SelectItem value="silver">Silver</SelectItem>
                      <SelectItem value="blue">Blue</SelectItem>
                      <SelectItem value="red">Red</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="license-plate">License Plate (Optional)</Label>
                  <Input id="license-plate" placeholder="ABC-1234" />
                </div>
              </div>
            </div>
          </Card>

          {/* Order Summary */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="font-medium mb-3">Order Summary</h3>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-sm">Regular Fuel (3 gal)</span>
                  <span className="text-sm">$10.47</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Delivery Fee</span>
                  <span className="text-sm">$15.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Service Fee</span>
                  <span className="text-sm">$5.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Tax</span>
                  <span className="text-sm">$2.45</span>
                </div>
                <div className="pt-2 mt-2 border-t flex justify-between font-medium">
                  <span>Total</span>
                  <span>$32.92</span>
                </div>
              </div>

              <div className="flex items-center mb-4">
                <div className="p-2 mr-3 rounded-full bg-green-100">
                  <Clock className="w-4 h-4 text-green-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium">Estimated Delivery Time</h4>
                  <p className="text-xs text-muted-foreground">20-30 minutes</p>
                </div>
              </div>

              <div className="flex items-center mb-4">
                <div className="p-2 mr-3 rounded-full bg-primary/10">
                  <CreditCard className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h4 className="text-sm font-medium">Payment Method</h4>
                  <p className="text-xs text-muted-foreground">Visa •••• 4242</p>
                </div>
                <Button variant="ghost" size="sm" className="ml-auto">
                  Change
                </Button>
              </div>

              <Button className="w-full">Confirm Order</Button>
            </div>
          </Card>

          {/* How It Works */}
          <Card>
            <div className="p-4">
              <h3 className="font-medium mb-3">How It Works</h3>

              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="flex items-center justify-center w-6 h-6 mr-3 text-white rounded-full bg-primary">
                    1
                  </div>
                  <div>
                    <h4 className="text-sm font-medium">Place Your Order</h4>
                    <p className="text-xs text-muted-foreground">
                      Select fuel type, quantity, and provide vehicle details
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex items-center justify-center w-6 h-6 mr-3 text-white rounded-full bg-primary">
                    2
                  </div>
                  <div>
                    <h4 className="text-sm font-medium">Fuel Delivery</h4>
                    <p className="text-xs text-muted-foreground">
                      A fuel delivery professional will arrive at your location
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex items-center justify-center w-6 h-6 mr-3 text-white rounded-full bg-primary">
                    3
                  </div>
                  <div>
                    <h4 className="text-sm font-medium">Get Back on the Road</h4>
                    <p className="text-xs text-muted-foreground">Your vehicle will be fueled up and ready to go</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}

