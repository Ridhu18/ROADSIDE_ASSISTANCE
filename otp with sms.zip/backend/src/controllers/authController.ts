import { Request, Response } from 'express';
import User from '../models/User';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import otpGenerator from 'otp-generator';
import axios from 'axios';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const FAST2SMS_API_KEY = process.env.FAST2SMS_API_KEY || 'your-fast2sms-api-key';

// Function to send OTP via SMS
const sendOTPViaSMS = async (mobileNumber: string, otp: string) => {
  try {
    if (!FAST2SMS_API_KEY || FAST2SMS_API_KEY === 'your-fast2sms-api-key') {
      console.error('Fast2SMS API key is not configured');
      throw new Error('SMS service is not configured');
    }

    console.log('Attempting to send SMS to:', mobileNumber);
    console.log('Using API key:', FAST2SMS_API_KEY.substring(0, 5) + '...');

    // Using Fast2SMS API with default sender ID
    const response = await axios.get('https://www.fast2sms.com/dev/bulkV2', {
      params: {
        authorization: FAST2SMS_API_KEY,
        route: 'q', // Using quick route
        numbers: mobileNumber,
        message: `Your RoadGuard verification code is: ${otp}. Valid for 5 minutes.`,
        flash: 0
      }
    });

    console.log('Fast2SMS API Response:', response.data);

    if (!response.data.return) {
      console.error('Fast2SMS API Error:', response.data);
      throw new Error(response.data.message || 'Failed to send SMS');
    }

    return response.data;
  } catch (error) {
    console.error('Detailed error in sendOTPViaSMS:', error);
    if (axios.isAxiosError(error)) {
      console.error('Axios error details:', {
        status: error.response?.status,
        data: error.response?.data,
        message: error.message
      });
      throw new Error(`SMS sending failed: ${error.response?.data?.message || error.message}`);
    }
    throw error;
  }
};

export const sendOTP = async (req: Request, res: Response) => {
  try {
    const { mobileNumber } = req.body;

    // Generate a 6-digit OTP
    const otp = otpGenerator.generate(6, {
      digits: true
    });

    // Set OTP expiration time (5 minutes from now)
    const otpExpiresAt = new Date(Date.now() + 5 * 60 * 1000);

    // Find or create user
    let user = await User.findOne({ mobileNumber });

    if (!user) {
      // Create new user if doesn't exist
      user = new User({
        mobileNumber,
        otp: {
          code: otp,
          expiresAt: otpExpiresAt,
        },
      });
      await user.save();
    } else {
      // Update existing user's OTP
      await User.updateOne(
        { mobileNumber },
        {
          $set: {
            "otp.code": otp,
            "otp.expiresAt": otpExpiresAt,
          },
        }
      );
    }

    // For development/testing, log the OTP instead of sending SMS
    if (process.env.NODE_ENV === 'development') {
      console.log(`Development mode - OTP for ${mobileNumber}: ${otp}`);
      return res.json({ message: "OTP sent successfully (development mode)" });
    }

    // Send OTP via SMS
    await sendOTPViaSMS(mobileNumber, otp);

    res.json({ message: "OTP sent successfully" });
  } catch (error) {
    console.error("Error in sendOTP:", error);
    res.status(500).json({ 
      error: error instanceof Error ? error.message : "Failed to send OTP",
      details: process.env.NODE_ENV === 'development' ? error : undefined
    });
  }
};

export const verifyOTP = async (req: Request, res: Response) => {
  try {
    const { mobileNumber, otp } = req.body;
    console.log('Verifying OTP for:', mobileNumber);

    const user = await User.findOne({ mobileNumber });
    console.log('User found:', user ? 'Yes' : 'No');

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (!user.otp || !user.otp.code || !user.otp.expiresAt) {
      console.log('No OTP found for user');
      return res.status(400).json({ error: 'No OTP found. Please request a new OTP.' });
    }

    if (user.otp.code !== otp) {
      console.log('Invalid OTP provided');
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    if (new Date() > user.otp.expiresAt) {
      console.log('OTP has expired');
      return res.status(400).json({ error: 'OTP has expired. Please request a new OTP.' });
    }

    // Clear OTP after successful verification using updateOne
    await User.updateOne(
      { _id: user._id },
      { $unset: { otp: 1 } }
    );

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id, mobileNumber: user.mobileNumber },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Return user data without requiring name field
    res.json({
      message: 'OTP verified successfully',
      token,
      user: {
        id: user._id,
        mobileNumber: user.mobileNumber,
        role: user.role || 'user',
        name: user.name || 'User', // Provide a default name if not set
      },
    });
  } catch (error) {
    console.error('Error in verifyOTP:', error);
    res.status(500).json({ 
      error: 'Failed to verify OTP',
      details: process.env.NODE_ENV === 'development' ? error : undefined
    });
  }
};

export const signup = async (req: Request, res: Response) => {
  try {
    const { name, mobileNumber, role, carDetails } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ mobileNumber });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Create new user
    const user = new User({
      name,
      mobileNumber,
      role,
      carDetails,
    });

    await user.save();

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id, mobileNumber: user.mobileNumber },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'User created successfully',
      token,
      user: {
        id: user._id,
        name: user.name,
        mobileNumber: user.mobileNumber,
        role: user.role,
        carDetails: user.carDetails,
      },
    });
  } catch (error) {
    console.error('Error in signup:', error);
    res.status(500).json({ error: 'Failed to create user' });
  }
}; 