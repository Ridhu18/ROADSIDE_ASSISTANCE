import type React from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { AlertTriangle, ArrowLeft, Car, Phone, MessageSquare, MapPin, Ambulance, Shield } from "lucide-react"

export default function EmergencyPage() {
  return (
    <div className="flex flex-col min-h-screen bg-red-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-red-600 text-white">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon" className="text-white">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">Emergency Assistance</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Emergency Banner */}
          <div className="p-4 mb-6 text-center bg-white rounded-lg shadow-sm">
            <div className="flex items-center justify-center p-3 mb-2 rounded-full bg-red-100 w-fit mx-auto">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="mb-2 text-xl font-bold">SOS Mode Activated</h2>
            <p className="text-muted-foreground">Help is on the way. Stay calm and follow the instructions below.</p>
          </div>

          {/* Location Info */}
          <Card className="p-4 mb-6">
            <div className="flex items-start">
              <MapPin className="w-5 h-5 mt-1 mr-3 text-primary" />
              <div>
                <h3 className="font-medium">Your Current Location</h3>
                <p className="text-sm text-muted-foreground">123 Main Street, Anytown</p>
                <p className="mt-1 text-xs text-muted-foreground">GPS Coordinates: 37.7749° N, 122.4194° W</p>
                <Button variant="outline" size="sm" className="mt-2">
                  Update Location
                </Button>
              </div>
            </div>
          </Card>

          {/* Emergency Actions */}
          <div className="grid grid-cols-1 gap-4 mb-6">
            <EmergencyAction
              icon={<Phone className="w-6 h-6 text-red-600" />}
              title="Call Emergency Services"
              description="Connect with 911 or local emergency"
              buttonText="Call Now"
              buttonVariant="destructive"
            />

            <EmergencyAction
              icon={<Car className="w-6 h-6 text-amber-600" />}
              title="Urgent Roadside Assistance"
              description="Priority towing and mechanical help"
              buttonText="Request Help"
              buttonVariant="default"
            />

            <EmergencyAction
              icon={<Ambulance className="w-6 h-6 text-blue-600" />}
              title="Medical Assistance"
              description="Request medical help for injuries"
              buttonText="Get Medical Help"
              buttonVariant="outline"
            />
          </div>

          {/* Emergency Contacts */}
          <h3 className="mb-3 text-lg font-medium">Emergency Contacts</h3>
          <div className="space-y-3 mb-6">
            <ContactCard name="John Doe" relation="Family" phone="+1 (555) 123-4567" />
            <ContactCard name="Jane Smith" relation="Friend" phone="+1 (555) 987-6543" />
          </div>

          {/* Status Updates */}
          <Card className="p-4 mb-6">
            <h3 className="mb-3 font-medium">Status Updates</h3>
            <div className="space-y-3">
              <StatusUpdate time="2:30 PM" message="Emergency request received. Finding nearby assistance." />
              <StatusUpdate time="2:32 PM" message="Towing service 'Quick Tow' has accepted your request." highlight />
              <StatusUpdate time="2:33 PM" message="Estimated arrival time: 15 minutes." />
            </div>
          </Card>

          {/* Cancel Emergency */}
          <Button variant="outline" className="w-full border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700">
            Cancel Emergency Mode
          </Button>
        </div>
      </main>

      {/* Emergency Chat */}
      <div className="fixed bottom-4 right-4">
        <Button className="w-12 h-12 rounded-full shadow-lg bg-red-600 hover:bg-red-700" size="icon">
          <MessageSquare className="w-6 h-6" />
        </Button>
      </div>
    </div>
  )
}

function EmergencyAction({
  icon,
  title,
  description,
  buttonText,
  buttonVariant = "default",
}: {
  icon: React.ReactNode
  title: string
  description: string
  buttonText: string
  buttonVariant?: "default" | "destructive" | "outline"
}) {
  return (
    <Card className="overflow-hidden">
      <div className="p-4">
        <div className="flex items-start">
          <div className="p-2 mr-3 rounded-full bg-red-50">{icon}</div>
          <div className="flex-1">
            <h3 className="font-medium">{title}</h3>
            <p className="mb-3 text-sm text-muted-foreground">{description}</p>
            <Button variant={buttonVariant} className="w-full">
              {buttonText}
            </Button>
          </div>
        </div>
      </div>
    </Card>
  )
}

function ContactCard({
  name,
  relation,
  phone,
}: {
  name: string
  relation: string
  phone: string
}) {
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center p-3">
        <div className="w-10 h-10 mr-3 overflow-hidden rounded-full bg-primary/10">
          <div className="flex items-center justify-center h-full text-primary">
            <Shield className="w-5 h-5" />
          </div>
        </div>
        <div className="flex-1">
          <h4 className="font-medium">{name}</h4>
          <p className="text-xs text-muted-foreground">{relation}</p>
        </div>
        <Button variant="ghost" size="icon">
          <Phone className="w-5 h-5 text-primary" />
        </Button>
      </div>
    </Card>
  )
}

function StatusUpdate({
  time,
  message,
  highlight = false,
}: {
  time: string
  message: string
  highlight?: boolean
}) {
  return (
    <div className={`p-3 rounded-lg ${highlight ? "bg-primary/10" : "bg-gray-50"}`}>
      <div className="flex items-start">
        <p className="w-16 text-xs font-medium text-muted-foreground">{time}</p>
        <p className={`flex-1 text-sm ${highlight ? "font-medium" : ""}`}>{message}</p>
      </div>
    </div>
  )
}

