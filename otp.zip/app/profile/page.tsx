import type React from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import {
  ArrowLeft,
  User,
  Car,
  CreditCard,
  Bell,
  Shield,
  LogOut,
  ChevronRight,
  Settings,
  Award,
  MapPin,
  Key,
  HelpCircle,
  MessageSquare,
} from "lucide-react"

export default function ProfilePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">Profile</h1>
          <div className="ml-auto">
            <Link href="/profile/settings">
              <Button variant="ghost" size="icon">
                <Settings className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Profile Header */}
          <Card className="mb-6">
            <div className="p-4">
              <div className="flex items-center">
                <div className="w-16 h-16 mr-4 overflow-hidden rounded-full bg-primary">
                  <img src="/placeholder.svg?height=64&width=64" alt="Profile" className="object-cover w-full h-full" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">John Doe</h2>
                  <p className="text-sm text-muted-foreground">john.doe@example.com</p>
                  <p className="text-sm text-muted-foreground">+1 (555) 123-4567</p>
                </div>
                <Button variant="outline" size="sm" className="ml-auto">
                  Edit
                </Button>
              </div>

              <div className="flex items-center mt-4 pt-4 border-t">
                <div className="flex-1 text-center">
                  <p className="text-sm text-muted-foreground">Member Since</p>
                  <p className="font-medium">Jan 2023</p>
                </div>
                <div className="flex-1 text-center border-x">
                  <p className="text-sm text-muted-foreground">Services Used</p>
                  <p className="font-medium">12</p>
                </div>
                <div className="flex-1 text-center">
                  <p className="text-sm text-muted-foreground">Reward Points</p>
                  <p className="font-medium">350</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Tabs */}
          <Tabs defaultValue="account" className="mb-6">
            <TabsList className="w-full">
              <TabsTrigger value="account" className="flex-1">
                Account
              </TabsTrigger>
              <TabsTrigger value="vehicles" className="flex-1">
                Vehicles
              </TabsTrigger>
              <TabsTrigger value="payment" className="flex-1">
                Payment
              </TabsTrigger>
            </TabsList>

            <TabsContent value="account" className="mt-4">
              <Card className="mb-4">
                <div className="p-4">
                  <h3 className="font-medium mb-3">Account Settings</h3>

                  <div className="space-y-3">
                    <ProfileLink
                      icon={<User className="w-5 h-5 text-primary" />}
                      title="Personal Information"
                      description="Manage your personal details"
                      href="/profile/personal"
                    />

                    <ProfileLink
                      icon={<Bell className="w-5 h-5 text-primary" />}
                      title="Notifications"
                      description="Manage your notification preferences"
                      href="/profile/notifications"
                    />

                    <ProfileLink
                      icon={<Shield className="w-5 h-5 text-primary" />}
                      title="Privacy & Security"
                      description="Manage your privacy settings"
                      href="/profile/privacy"
                    />

                    <ProfileLink
                      icon={<MapPin className="w-5 h-5 text-primary" />}
                      title="Saved Locations"
                      description="Manage your saved addresses"
                      href="/profile/locations"
                    />

                    <ProfileLink
                      icon={<Key className="w-5 h-5 text-primary" />}
                      title="Change Password"
                      description="Update your password"
                      href="/profile/password"
                    />
                  </div>
                </div>
              </Card>

              <Card className="mb-4">
                <div className="p-4">
                  <h3 className="font-medium mb-3">Preferences</h3>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Dark Mode</h4>
                        <p className="text-sm text-muted-foreground">Switch between light and dark themes</p>
                      </div>
                      <Switch />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Location Services</h4>
                        <p className="text-sm text-muted-foreground">Allow app to access your location</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Push Notifications</h4>
                        <p className="text-sm text-muted-foreground">Receive push notifications</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </div>
              </Card>

              <Card>
                <div className="p-4">
                  <h3 className="font-medium mb-3">Support</h3>

                  <div className="space-y-3">
                    <ProfileLink
                      icon={<HelpCircle className="w-5 h-5 text-primary" />}
                      title="Help Center"
                      description="Get help with the app"
                      href="/help"
                    />

                    <ProfileLink
                      icon={<MessageSquare className="w-5 h-5 text-primary" />}
                      title="Contact Support"
                      description="Reach out to our support team"
                      href="/support"
                    />
                  </div>

                  <Button
                    variant="outline"
                    className="w-full mt-4 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </Button>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="vehicles">
              <Card className="mb-4">
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium">My Vehicles</h3>
                    <Button size="sm">Add Vehicle</Button>
                  </div>

                  <div className="space-y-3">
                    <VehicleCard
                      make="Toyota"
                      model="Camry"
                      year="2019"
                      color="Silver"
                      licensePlate="ABC-1234"
                      primary
                    />

                    <VehicleCard make="Honda" model="CR-V" year="2020" color="Blue" licensePlate="XYZ-5678" />
                  </div>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="payment">
              <Card className="mb-4">
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium">Payment Methods</h3>
                    <Button size="sm">Add Method</Button>
                  </div>

                  <div className="space-y-3">
                    <PaymentCard type="Visa" number="•••• 4242" expiry="05/25" primary />

                    <PaymentCard type="Mastercard" number="•••• 5678" expiry="12/24" />
                  </div>
                </div>
              </Card>

              <Card>
                <div className="p-4">
                  <h3 className="font-medium mb-3">Billing History</h3>

                  <div className="space-y-3">
                    <BillingItem service="Towing Service" date="May 15, 2023" amount="$120.00" status="Paid" />

                    <BillingItem service="Flat Tire Repair" date="March 3, 2023" amount="$75.00" status="Paid" />

                    <BillingItem service="Battery Jump Start" date="January 22, 2023" amount="$60.00" status="Paid" />
                  </div>

                  <Button variant="outline" className="w-full mt-4">
                    View All Transactions
                  </Button>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="sticky bottom-0 z-10 bg-white border-t">
        <div className="container grid h-16 grid-cols-4">
          <NavItem icon={<Car />} label="Home" href="/" />
          <NavItem icon={<MapPin />} label="Map" href="/map" />
          <NavItem icon={<Award />} label="Rewards" href="/rewards" />
          <NavItem icon={<User />} label="Profile" active href="/profile" />
        </div>
      </nav>
    </div>
  )
}

function ProfileLink({
  icon,
  title,
  description,
  href,
}: {
  icon: React.ReactNode
  title: string
  description: string
  href: string
}) {
  return (
    <Link href={href}>
      <div className="flex items-center p-3 rounded-lg hover:bg-gray-100">
        <div className="p-2 mr-3 rounded-full bg-primary/10">{icon}</div>
        <div className="flex-1">
          <h4 className="font-medium">{title}</h4>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground" />
      </div>
    </Link>
  )
}

function VehicleCard({
  make,
  model,
  year,
  color,
  licensePlate,
  primary = false,
}: {
  make: string
  model: string
  year: string
  color: string
  licensePlate: string
  primary?: boolean
}) {
  return (
    <div className={`p-3 rounded-lg border ${primary ? "border-primary bg-primary/5" : ""}`}>
      <div className="flex items-start">
        <div className="p-2 mr-3 rounded-full bg-gray-100">
          <Car className="w-5 h-5 text-gray-600" />
        </div>
        <div className="flex-1">
          <div className="flex items-center">
            <h4 className="font-medium">
              {make} {model} ({year})
            </h4>
            {primary && (
              <span className="ml-2 px-2 py-0.5 text-xs font-medium text-primary bg-primary/10 rounded-full">
                Primary
              </span>
            )}
          </div>
          <p className="text-sm text-muted-foreground">Color: {color}</p>
          <p className="text-sm text-muted-foreground">License: {licensePlate}</p>
        </div>
        <Button variant="ghost" size="sm">
          Edit
        </Button>
      </div>
    </div>
  )
}

function PaymentCard({
  type,
  number,
  expiry,
  primary = false,
}: {
  type: string
  number: string
  expiry: string
  primary?: boolean
}) {
  return (
    <div className={`p-3 rounded-lg border ${primary ? "border-primary bg-primary/5" : ""}`}>
      <div className="flex items-start">
        <div className="p-2 mr-3 rounded-full bg-gray-100">
          <CreditCard className="w-5 h-5 text-gray-600" />
        </div>
        <div className="flex-1">
          <div className="flex items-center">
            <h4 className="font-medium">
              {type} {number}
            </h4>
            {primary && (
              <span className="ml-2 px-2 py-0.5 text-xs font-medium text-primary bg-primary/10 rounded-full">
                Default
              </span>
            )}
          </div>
          <p className="text-sm text-muted-foreground">Expires: {expiry}</p>
        </div>
        <Button variant="ghost" size="sm">
          Edit
        </Button>
      </div>
    </div>
  )
}

function BillingItem({
  service,
  date,
  amount,
  status,
}: {
  service: string
  date: string
  amount: string
  status: string
}) {
  return (
    <div className="p-3 rounded-lg border">
      <div className="flex items-center justify-between mb-1">
        <h4 className="font-medium">{service}</h4>
        <span className="font-medium">{amount}</span>
      </div>
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{date}</p>
        <span className="px-2 py-0.5 text-xs font-medium text-green-700 bg-green-100 rounded-full">{status}</span>
      </div>
    </div>
  )
}

function NavItem({
  icon,
  label,
  active = false,
  href,
}: {
  icon: React.ReactNode
  label: string
  active?: boolean
  href: string
}) {
  return (
    <Link href={href} className="flex items-center justify-center">
      <div className={`flex flex-col items-center justify-center ${active ? "text-primary" : "text-muted-foreground"}`}>
        <div>{icon}</div>
        <span className="text-xs">{label}</span>
      </div>
    </Link>
  )
}

