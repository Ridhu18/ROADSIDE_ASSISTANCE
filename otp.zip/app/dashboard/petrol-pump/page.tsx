"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Droplet,
  Settings,
  Bell,
  Clock,
  Calendar,
  CheckCircle,
  XCircle,
  MapPin,
  Phone,
  MessageSquare,
  Star,
  Fuel,
  Truck,
  BarChart,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

export default function PetrolPumpDashboard() {
  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="hidden md:flex w-64 flex-col bg-white border-r">
        <div className="flex items-center h-16 px-6 border-b">
          <Droplet className="w-6 h-6 text-primary mr-2" />
          <h1 className="font-bold text-lg">Fuel Delivery Portal</h1>
        </div>

        <div className="flex flex-col flex-1 p-4">
          <nav className="space-y-1">
            <Button variant="ghost" className="w-full justify-start">
              <BarChart className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Droplet className="mr-2 h-4 w-4" />
              Fuel Requests
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Calendar className="mr-2 h-4 w-4" />
              Schedule
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <CheckCircle className="mr-2 h-4 w-4" />
              Completed Deliveries
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Truck className="mr-2 h-4 w-4" />
              Inventory
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </nav>
        </div>

        <div className="p-4 border-t">
          <div className="flex items-center">
            <Avatar className="h-9 w-9 mr-2">
              <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Avatar" />
              <AvatarFallback>RP</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">Robert Parker</p>
              <p className="text-xs text-muted-foreground">Fuel Delivery Agent</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        {/* Header */}
        <header className="bg-white border-b h-16 flex items-center justify-between px-6">
          <div className="md:hidden">
            <Droplet className="w-6 h-6 text-primary" />
          </div>

          <div className="flex items-center ml-auto">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <MessageSquare className="h-5 w-5" />
            </Button>
            <Avatar className="h-8 w-8 ml-2">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Avatar" />
              <AvatarFallback>RP</AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">Fuel Delivery Dashboard</h1>
              <p className="text-muted-foreground">Manage fuel delivery requests and inventory</p>
            </div>
            <div className="flex items-center mt-4 md:mt-0">
              <Badge variant="outline" className="bg-green-100 text-green-800 mr-2">
                Available
              </Badge>
              <Button variant="outline">Go Offline</Button>
            </div>
          </div>

          {/* Inventory Status */}
          <Card className="mb-6">
            <CardHeader className="pb-2">
              <CardTitle>Fuel Inventory</CardTitle>
              <CardDescription>Current fuel levels in delivery vehicles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                      <span className="text-sm font-medium">Petrol</span>
                    </div>
                    <span className="text-sm">85% (42.5 L)</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                      <span className="text-sm font-medium">Diesel</span>
                    </div>
                    <span className="text-sm">70% (35 L)</span>
                  </div>
                  <Progress value={70} className="h-2" />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>
                      <span className="text-sm font-medium">Premium Petrol</span>
                    </div>
                    <span className="text-sm">60% (30 L)</span>
                  </div>
                  <Progress value={60} className="h-2" />
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <Button variant="outline" size="sm">
                  Refill Inventory
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Stats Cards */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-6">
            <StatsCard
              title="Today's Deliveries"
              value="8"
              icon={<Droplet className="h-5 w-5" />}
              description="5 completed, 3 pending"
            />
            <StatsCard
              title="Response Time"
              value="12 min"
              icon={<Clock className="h-5 w-5" />}
              description="Average today"
            />
            <StatsCard
              title="Rating"
              value="4.7/5"
              icon={<Star className="h-5 w-5" />}
              description="Based on 56 reviews"
            />
            <StatsCard
              title="Fuel Delivered"
              value="85 L"
              icon={<Fuel className="h-5 w-5" />}
              description="Today's total"
            />
          </div>

          {/* Active Delivery */}
          <Card className="mb-6 border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Active Delivery</CardTitle>
                  <CardDescription>Currently assigned fuel delivery</CardDescription>
                </div>
                <Badge className="bg-blue-100 text-blue-800">En Route</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div className="space-y-3">
                  <div className="flex items-start">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Customer" />
                      <AvatarFallback>SJ</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">Sarah Johnson</h3>
                      <p className="text-sm text-muted-foreground">Petrol • 10 Liters • Honda Civic</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 mr-2 text-muted-foreground flex-shrink-0" />
                    <div>
                      <p className="text-sm">456 Oak Avenue, Anytown</p>
                      <p className="text-xs text-muted-foreground">1.8 miles away • 8 min ETA</p>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex items-center">
                      <Phone className="h-4 w-4 mr-1" />
                      Call
                    </Button>
                    <Button size="sm" variant="outline" className="flex items-center">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Message
                    </Button>
                    <Button size="sm" variant="outline" className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      Directions
                    </Button>
                  </div>
                </div>

                <div className="mt-4 md:mt-0 flex flex-col items-center">
                  <div className="text-center mb-2">
                    <p className="text-sm text-muted-foreground">Delivery Progress</p>
                    <div className="flex items-center justify-center">
                      <Truck className="h-4 w-4 mr-1 text-blue-500" />
                      <p className="text-sm font-medium">Started 10 mins ago</p>
                    </div>
                  </div>

                  <div className="w-full max-w-[200px]">
                    <Progress value={50} className="h-2" />
                    <div className="flex justify-between mt-1">
                      <span className="text-xs">Accepted</span>
                      <span className="text-xs">En Route</span>
                      <span className="text-xs">Delivered</span>
                    </div>
                  </div>

                  <Button className="mt-4">Mark as Delivered</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pending Requests */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Pending Fuel Requests</CardTitle>
              <CardDescription>Nearby fuel delivery requests</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="all">
                <TabsList className="mb-4">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="urgent">Urgent</TabsTrigger>
                  <TabsTrigger value="nearby">Nearby</TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="space-y-4">
                  <FuelRequestCard
                    name="David Wilson"
                    fuelType="Diesel"
                    amount="15 L"
                    car="Ford F-150"
                    location="202 Maple Drive, Anytown"
                    distance="4.7 miles"
                    time="8 mins ago"
                    urgent={false}
                  />
                  <FuelRequestCard
                    name="Emily Davis"
                    fuelType="Petrol"
                    amount="8 L"
                    car="Nissan Altima"
                    location="101 Elm Street, Anytown"
                    distance="3.2 miles"
                    time="15 mins ago"
                    urgent={true}
                  />
                  <FuelRequestCard
                    name="Michael Brown"
                    fuelType="Premium Petrol"
                    amount="12 L"
                    car="BMW 3 Series"
                    location="789 Pine Road, Anytown"
                    distance="2.5 miles"
                    time="22 mins ago"
                    urgent={false}
                  />
                </TabsContent>

                <TabsContent value="urgent" className="space-y-4">
                  <FuelRequestCard
                    name="Emily Davis"
                    fuelType="Petrol"
                    amount="8 L"
                    car="Nissan Altima"
                    location="101 Elm Street, Anytown"
                    distance="3.2 miles"
                    time="15 mins ago"
                    urgent={true}
                  />
                </TabsContent>

                <TabsContent value="nearby" className="space-y-4">
                  <FuelRequestCard
                    name="Michael Brown"
                    fuelType="Premium Petrol"
                    amount="12 L"
                    car="BMW 3 Series"
                    location="789 Pine Road, Anytown"
                    distance="2.5 miles"
                    time="22 mins ago"
                    urgent={false}
                  />
                  <FuelRequestCard
                    name="Emily Davis"
                    fuelType="Petrol"
                    amount="8 L"
                    car="Nissan Altima"
                    location="101 Elm Street, Anytown"
                    distance="3.2 miles"
                    time="15 mins ago"
                    urgent={true}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Today's Schedule */}
          <Card>
            <CardHeader>
              <CardTitle>Today's Schedule</CardTitle>
              <CardDescription>Your upcoming deliveries</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <ScheduleItem
                  time="2:30 PM"
                  name="Sarah Johnson"
                  details="Petrol • 10 L • Honda Civic"
                  status="in-progress"
                />
                <ScheduleItem
                  time="3:45 PM"
                  name="David Wilson"
                  details="Diesel • 15 L • Ford F-150"
                  status="scheduled"
                />
                <ScheduleItem
                  time="5:00 PM"
                  name="Michael Brown"
                  details="Premium Petrol • 12 L • BMW 3 Series"
                  status="scheduled"
                />
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}

function StatsCard({
  title,
  value,
  icon,
  description,
}: {
  title: string
  value: string
  icon: React.ReactNode
  description: string
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
          </div>
          <div className="p-2 rounded-full bg-primary/10">
            <div className="text-primary">{icon}</div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-2">{description}</p>
      </CardContent>
    </Card>
  )
}

function FuelRequestCard({
  name,
  fuelType,
  amount,
  car,
  location,
  distance,
  time,
  urgent,
}: {
  name: string
  fuelType: string
  amount: string
  car: string
  location: string
  distance: string
  time: string
  urgent: boolean
}) {
  return (
    <Card className={urgent ? "border-l-4 border-l-red-500" : ""}>
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div className="space-y-2">
            <div className="flex items-start">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Customer" />
                <AvatarFallback>{name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center">
                  <h3 className="font-medium">{name}</h3>
                  {urgent && (
                    <Badge variant="outline" className="ml-2 bg-red-100 text-red-800">
                      Urgent
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {fuelType} • {amount} • {car}
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <MapPin className="h-5 w-5 mr-2 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-sm">{location}</p>
                <p className="text-xs text-muted-foreground">
                  {distance} away • Requested {time}
                </p>
              </div>
            </div>
          </div>

          <div className="flex space-x-2 mt-4 md:mt-0">
            <Button size="sm" variant="outline" className="flex items-center">
              <XCircle className="h-4 w-4 mr-1" />
              Decline
            </Button>
            <Button size="sm" className="flex items-center">
              <CheckCircle className="h-4 w-4 mr-1" />
              Accept
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ScheduleItem({
  time,
  name,
  details,
  status,
}: {
  time: string
  name: string
  details: string
  status: "scheduled" | "in-progress" | "completed"
}) {
  const statusColors = {
    scheduled: "bg-gray-100 text-gray-800",
    "in-progress": "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
  }

  const statusLabels = {
    scheduled: "Scheduled",
    "in-progress": "In Progress",
    completed: "Completed",
  }

  return (
    <div className="flex items-center p-3 border rounded-lg">
      <div className="w-16 text-center">
        <p className="font-medium">{time}</p>
      </div>
      <div className="flex-1 ml-4">
        <p className="font-medium">{name}</p>
        <p className="text-sm text-muted-foreground">{details}</p>
      </div>
      <Badge variant="outline" className={statusColors[status]}>
        {statusLabels[status]}
      </Badge>
    </div>
  )
}

