import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import { ArrowLeft, Car, Phone, MessageSquare, MapPin, Clock, CheckCircle, Star, AlertTriangle } from "lucide-react"

export default function TrackingPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">Track Service</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Service Status */}
          <Card className="mb-6 overflow-hidden">
            <div className="p-4 bg-primary/5 border-b">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium">Mechanic Service</h3>
                <span className="px-2 py-1 text-xs font-medium text-white rounded-full bg-green-500">In Progress</span>
              </div>
              <p className="text-sm text-muted-foreground mb-3">Request ID: #RG-12345 • May 22, 2023</p>

              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span>Request Received</span>
                  <CheckCircle className="w-4 h-4 text-green-600" />
                </div>
                <Progress value={100} className="h-1" />

                <div className="flex justify-between items-center text-sm">
                  <span>Mechanic Assigned</span>
                  <CheckCircle className="w-4 h-4 text-green-600" />
                </div>
                <Progress value={100} className="h-1" />

                <div className="flex justify-between items-center text-sm">
                  <span>En Route</span>
                  <CheckCircle className="w-4 h-4 text-green-600" />
                </div>
                <Progress value={100} className="h-1" />

                <div className="flex justify-between items-center text-sm font-medium">
                  <span>Arriving Soon</span>
                  <Clock className="w-4 h-4 text-primary" />
                </div>
                <Progress value={75} className="h-1" />

                <div className="flex justify-between items-center text-sm text-muted-foreground">
                  <span>Service Complete</span>
                </div>
                <Progress value={0} className="h-1" />
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1 text-primary" />
                  <span className="font-medium">ETA: 10 minutes</span>
                </div>
                <span className="text-sm">Arriving at 2:45 PM</span>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1">
                  <Phone className="w-4 h-4 mr-2" />
                  Call
                </Button>
                <Button variant="outline" className="flex-1">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Message
                </Button>
                <Button className="flex-1">
                  <MapPin className="w-4 h-4 mr-2" />
                  Track
                </Button>
              </div>
            </div>
          </Card>

          {/* Map View */}
          <Card className="mb-6 overflow-hidden">
            <div className="relative aspect-[16/9] bg-gray-100">
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-muted-foreground">Map view loading...</p>
              </div>
              <div className="absolute bottom-4 right-4">
                <Button size="sm" className="shadow-md">
                  <MapPin className="w-4 h-4 mr-2" />
                  View Full Map
                </Button>
              </div>
            </div>
          </Card>

          {/* Service Provider */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="font-medium mb-3">Service Provider</h3>
              <div className="flex items-start">
                <div className="w-16 h-16 mr-3 overflow-hidden rounded-lg bg-gray-100 flex items-center justify-center">
                  <Car className="w-8 h-8 text-primary" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium">John's Auto Repair</h4>
                  <p className="text-sm text-muted-foreground">General Mechanic • Engine Specialist</p>
                  <div className="flex items-center mt-1 mb-2">
                    <Star className="w-4 h-4 mr-1 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-medium">4.8</span>
                    <span className="ml-1 text-xs text-muted-foreground">(124 reviews)</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-gray-200 mr-2">
                      <img
                        src="/placeholder.svg?height=24&width=24"
                        alt="Mechanic"
                        className="w-full h-full rounded-full"
                      />
                    </div>
                    <span className="text-sm">Mike Johnson (Technician)</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Service Details */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="font-medium mb-3">Service Details</h3>

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Service Type</span>
                  <span className="text-sm font-medium">Engine Diagnostics</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Vehicle</span>
                  <span className="text-sm font-medium">Toyota Camry (Silver)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Issue Reported</span>
                  <span className="text-sm font-medium">Car won't start</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Location</span>
                  <span className="text-sm font-medium">123 Main Street</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Estimated Cost</span>
                  <span className="text-sm font-medium">$80 - $150</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Actions */}
          <div className="space-y-3 mb-6">
            <Button variant="outline" className="w-full">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Report an Issue
            </Button>
            <Button variant="outline" className="w-full text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700">
              Cancel Service
            </Button>
          </div>

          {/* Tips */}
          <Card>
            <div className="p-4">
              <h3 className="font-medium mb-3">Tips</h3>

              <div className="space-y-3">
                <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                  <h4 className="text-sm font-medium text-amber-800 mb-1">Prepare for the Mechanic</h4>
                  <p className="text-xs text-amber-700">
                    Have your vehicle information ready and be prepared to describe the issue in detail.
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                  <h4 className="text-sm font-medium text-blue-800 mb-1">Stay Near Your Vehicle</h4>
                  <p className="text-xs text-blue-700">The mechanic will need access to your vehicle upon arrival.</p>
                </div>

                <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                  <h4 className="text-sm font-medium text-green-800 mb-1">Payment Information</h4>
                  <p className="text-xs text-green-700">
                    Payment will be processed through the app after service completion.
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}

