import type React from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { Search, Car, Navigation, Droplet, Stethoscope, Phone, Filter, Layers, Locate, ChevronUp } from "lucide-react"

export default function MapPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Map View (Full Screen) */}
      <div className="fixed inset-0 bg-gray-200">
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-muted-foreground">Map loading...</p>
        </div>

        {/* Map Controls */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <Button size="icon" variant="secondary" className="bg-white shadow-md">
            <Layers className="w-5 h-5" />
          </Button>
          <Button size="icon" variant="secondary" className="bg-white shadow-md">
            <Locate className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 bg-white shadow-md">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <Car className="w-6 h-6" />
            </Button>
          </Link>
          <div className="relative flex-1 mx-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input placeholder="Search for services..." className="pl-9" />
          </div>
          <Button variant="ghost" size="icon">
            <Filter className="w-5 h-5" />
          </Button>
        </div>
      </header>

      {/* Bottom Sheet */}
      <div className="fixed bottom-0 left-0 right-0 z-10 bg-white rounded-t-xl shadow-lg">
        <div className="flex justify-center py-2">
          <div className="w-12 h-1 rounded-full bg-gray-300"></div>
        </div>

        <div className="container px-4 pb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Nearby Services</h2>
            <Button variant="ghost" size="sm">
              <ChevronUp className="w-5 h-5 mr-1" />
              Expand
            </Button>
          </div>

          {/* Service Tabs */}
          <Tabs defaultValue="all" className="mb-4">
            <TabsList className="w-full">
              <TabsTrigger value="all" className="flex-1">
                All
              </TabsTrigger>
              <TabsTrigger value="mechanics" className="flex-1">
                Mechanics
              </TabsTrigger>
              <TabsTrigger value="towing" className="flex-1">
                Towing
              </TabsTrigger>
              <TabsTrigger value="fuel" className="flex-1">
                Fuel
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-4">
              <div className="space-y-3">
                <MapServiceCard
                  name="John's Auto Repair"
                  type="Mechanic"
                  distance="0.8 miles"
                  rating={4.8}
                  eta="10 min"
                  href="/services/mechanic/1"
                />

                <MapServiceCard
                  name="Rapid Towing Inc."
                  type="Towing"
                  distance="1.2 miles"
                  rating={4.6}
                  eta="15 min"
                  href="/services/towing/1"
                />

                <MapServiceCard
                  name="City Fuel Delivery"
                  type="Fuel"
                  distance="2.5 miles"
                  rating={4.7}
                  eta="20 min"
                  href="/services/fuel/1"
                />

                <MapServiceCard
                  name="Emergency Medical Services"
                  type="Medical"
                  distance="3.0 miles"
                  rating={4.9}
                  eta="12 min"
                  href="/services/medical/1"
                />
              </div>
            </TabsContent>

            <TabsContent value="mechanics">
              <div className="p-8 text-center">
                <p className="text-muted-foreground">Mechanics will appear here</p>
              </div>
            </TabsContent>

            <TabsContent value="towing">
              <div className="p-8 text-center">
                <p className="text-muted-foreground">Towing services will appear here</p>
              </div>
            </TabsContent>

            <TabsContent value="fuel">
              <div className="p-8 text-center">
                <p className="text-muted-foreground">Fuel delivery services will appear here</p>
              </div>
            </TabsContent>
          </Tabs>

          {/* Quick Actions */}
          <div className="grid grid-cols-4 gap-2 mb-4">
            <QuickAction icon={<Car />} label="Mechanic" href="/services/mechanic" />
            <QuickAction icon={<Navigation />} label="Towing" href="/services/towing" />
            <QuickAction icon={<Droplet />} label="Fuel" href="/services/fuel" />
            <QuickAction icon={<Phone />} label="Emergency" href="/emergency" />
          </div>
        </div>
      </div>
    </div>
  )
}

function MapServiceCard({
  name,
  type,
  distance,
  rating,
  eta,
  href,
}: {
  name: string
  type: string
  distance: string
  rating: number
  eta: string
  href: string
}) {
  return (
    <Link href={href}>
      <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
        <div className="p-3">
          <div className="flex items-start">
            <div className="w-10 h-10 mr-3 overflow-hidden rounded-lg bg-gray-100 flex items-center justify-center">
              {type === "Mechanic" && <Car className="w-5 h-5 text-primary" />}
              {type === "Towing" && <Navigation className="w-5 h-5 text-primary" />}
              {type === "Fuel" && <Droplet className="w-5 h-5 text-primary" />}
              {type === "Medical" && <Stethoscope className="w-5 h-5 text-primary" />}
            </div>
            <div className="flex-1">
              <h3 className="font-medium">{name}</h3>
              <div className="flex items-center mb-1">
                <span className="text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full mr-2">{type}</span>
                <span className="text-xs text-muted-foreground">{distance}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <svg className="w-4 h-4 text-yellow-500 fill-current" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                  <span className="ml-1 text-sm font-medium">{rating}</span>
                </div>
                <span className="text-sm font-medium">ETA: {eta}</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </Link>
  )
}

function QuickAction({
  icon,
  label,
  href,
}: {
  icon: React.ReactNode
  label: string
  href: string
}) {
  return (
    <Link href={href}>
      <div className="flex flex-col items-center p-2 rounded-lg bg-white border hover:bg-gray-50">
        <div className="p-2 mb-1 rounded-full bg-primary/10">
          <div className="text-primary w-5 h-5">{icon}</div>
        </div>
        <span className="text-xs">{label}</span>
      </div>
    </Link>
  )
}

