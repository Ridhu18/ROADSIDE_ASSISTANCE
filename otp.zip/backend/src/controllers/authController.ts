import { Request, Response } from 'express';
import User from '../models/User';

// Generate a random 6-digit OTP
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export const sendOTP = async (req: Request, res: Response) => {
  try {
    console.log('Received sendOTP request:', req.body);
    const { mobileNumber } = req.body;

    if (!mobileNumber) {
      console.log('Error: Mobile number is missing');
      return res.status(400).json({ error: 'Mobile number is required' });
    }

    // Find user
    const user = await User.findOne({ mobileNumber });
    console.log('Found user:', user);
    
    if (!user) {
      console.log('Error: User not found for mobile number:', mobileNumber);
      return res.status(404).json({ error: 'User not found. Please sign up first.' });
    }

    // Generate OTP
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // OTP expires in 10 minutes

    // Update only the OTP field
    await User.updateOne(
      { mobileNumber },
      { 
        $set: { 
          'otp.code': otp,
          'otp.expiresAt': expiresAt
        }
      }
    );

    // TODO: Integrate with SMS service to send OTP
    console.log(`OTP for ${mobileNumber}: ${otp}`);

    return res.json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Error in sendOTP:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

export const verifyOTP = async (req: Request, res: Response) => {
  try {
    console.log('Received verifyOTP request:', req.body);
    const { mobileNumber, otp } = req.body;

    if (!mobileNumber || !otp) {
      console.log('Error: Missing required fields');
      return res.status(400).json({ error: 'Mobile number and OTP are required' });
    }

    const user = await User.findOne({ mobileNumber });
    console.log('Found user:', user);

    if (!user) {
      console.log('Error: User not found');
      return res.status(404).json({ error: 'User not found' });
    }

    if (!user.otp || !user.otp.code || !user.otp.expiresAt) {
      console.log('Error: No OTP found for user');
      return res.status(400).json({ error: 'No OTP found. Please request a new OTP.' });
    }

    if (new Date() > user.otp.expiresAt) {
      console.log('Error: OTP expired');
      return res.status(400).json({ error: 'OTP has expired. Please request a new OTP.' });
    }

    if (user.otp.code !== otp) {
      console.log('Error: Invalid OTP');
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    // Clear OTP after successful verification
    await User.updateOne(
      { mobileNumber },
      { $unset: { otp: 1 } }
    );

    return res.json({
      message: 'OTP verified successfully',
      user: {
        id: user._id,
        name: user.name,
        mobileNumber: user.mobileNumber,
        role: user.role,
      },
    });
  } catch (error) {
    console.error('Error in verifyOTP:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

export const signup = async (req: Request, res: Response) => {
  try {
    console.log('Received signup request:', req.body);
    const { name, mobileNumber, role } = req.body;

    if (!name || !mobileNumber) {
      console.log('Error: Missing required fields');
      return res.status(400).json({ error: 'Name and mobile number are required' });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ mobileNumber });
    if (existingUser) {
      console.log('Error: User already exists');
      return res.status(400).json({ error: 'User with this mobile number already exists' });
    }

    // Create new user
    const user = await User.create({
      name,
      mobileNumber,
      role: role || 'user',
    });

    return res.json({
      message: 'User registered successfully',
      user: {
        id: user._id,
        name: user.name,
        mobileNumber: user.mobileNumber,
        role: user.role,
      },
    });
  } catch (error) {
    console.error('Error in signup:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}; 