import express from 'express';
import { sendOTP, verifyOTP, signup } from '../controllers/authController';

const router = express.Router();

router.post('/otp/send', sendOTP);
router.post('/otp/verify', verifyOTP);
router.post('/signup', signup);

export default router; 